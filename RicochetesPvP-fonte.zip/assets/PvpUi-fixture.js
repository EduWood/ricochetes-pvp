// JavaScript | PvpUi-fixture.js | local preview only | sanitized replay adapter
export class PvpUi {
  constructor(fixture) {
    this.view={code:'replay-local',status:'playing',seat:0,boundary:fixture.boundary,
      battle:{active:fixture.activeIndex,turn:6,side:0,heroes:fixture.heroes}};
    this.visible=true;this.overlay=document.getElementById('overlay');
    this.renderer={canvas:document.getElementById('pvp-canvas')};
    this.aim={angle:fixture.angle,power:fixture.power};this.roster=[];this.selected=new Set();
  }
  snapshot(){return {status:this.view.status,turn:this.view.battle.turn}}
  playingReplay(){return false}
  canAim(){return this.view.battle.side===0}
}
