# Python | publish.py | Windows/Python 3.10+ | package and verify local deliverables
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parent
outputs = root.parent.parent / 'outputs'
exe = root / 'dist/RicochetesPvP.exe'
for mode, report in [('--self-test', 'frozen-selftest.json'), ('--smoke-ui', 'frozen-ui.json'), ('--extract', 'frozen-extracted')]:
    subprocess.run([str(exe), mode, str(root / report)], check=True, timeout=45, creationflags=subprocess.CREATE_NO_WINDOW)
test = json.loads((root / 'frozen-selftest.json').read_text(encoding='utf-8'))
assert test['frozen'] and test['version'] == '1.3.0'
for name in ('manifest.json', 'bootstrap.js', 'popup.html', 'popup.js'):
    data = (root / 'extension' / name).read_bytes()
    assert test['files'][name] == hashlib.sha256(data).hexdigest()
    assert (root / 'frozen-extracted' / name).read_bytes() == data
ui = json.loads((root / 'frozen-ui.json').read_text(encoding='utf-8'))
assert ui['frozen'] and ui['height'] <= 590 and ui['width'] <= 650, ui
shutil.copyfile(exe, outputs / 'RicochetesPvP-1.3.exe')
try:
    shutil.copyfile(exe, outputs / 'RicochetesPvP.exe')
except PermissionError:
    print('Old executable is open. Use RicochetesPvP-1.3.exe.')
shutil.copytree(root / 'extension', outputs / 'RicochetesPvP-extensao', dirs_exist_ok=True)
readme = outputs / 'RicochetesPvP-leia-me.md'
shutil.copyfile(readme, root / 'README.md')
with zipfile.ZipFile(outputs / 'RicochetesPvP-extensao.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in (root / 'extension').iterdir():
        archive.write(file, 'RicochetesPvP-extensao/' + file.name)
    archive.write(readme, 'LEIA-ME.md')
with zipfile.ZipFile(outputs / 'RicochetesPvP-fonte.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in ('app.py', 'build.ps1', 'package_extension.py', 'publish.py', 'loader-template.js', 'test_setup.py', 'test_extension.cjs', 'requirements.txt', 'version.txt', 'README.md', 'farm-pvp-ricochetes.js'):
        archive.write(root / name, name)
    for file in (root / 'extension').iterdir():
        archive.write(file, 'extension/' + file.name)
hashes = [hashlib.sha256((outputs / name).read_bytes()).hexdigest() + '  ' + name for name in ('RicochetesPvP-1.3.exe', 'RicochetesPvP-extensao.zip', 'RicochetesPvP-fonte.zip')]
(outputs / 'RicochetesPvP.sha256').write_text('\n'.join(hashes) + '\n', encoding='utf-8')
print(json.dumps({'version': test['version'], 'embeddedFilesMatch': True, 'ui': ui, 'sha256': hashes}, indent=2))
