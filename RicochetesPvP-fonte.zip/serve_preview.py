# Python | serve_preview.py | Python 3.10+ | loopback-only UI test
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'farm-pvp-ricochetes.js').read_text(encoding='utf-8')
source=source.replace("if (location.origin !== 'https://farmricochet.com') throw new Error('Abra o Farm Ricochet.');", "if (location.hostname !== '127.0.0.1') throw new Error('Prévia local.');")
(root/'preview/overlay.js').write_text(source,encoding='utf-8')
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(root)))
print(f'http://127.0.0.1:{server.server_port}/preview/',flush=True)
server.serve_forever()
